#!/usr/bin/env python
# -*- coding:utf-8 -*-

"""
py2 の方に rescaling-term を導入するための臨時モジュール
"""
import numpy as np
from numpy.random import multinomial, uniform, dirichlet

def get_rescaling_term(var_theta, num_word):
    """
    rescaling-term を計算する
    """
    return [
        sum(var_theta[cat_id][word_id] for cat_id in range(len(var_theta)))
        for word_id in range(num_word)
    ]

def get_rescaled_theta(var_theta, num_word):
    """
    rescaling-term に基づきwの確率を計算する
    """
    rescaling_term = get_rescaling_term(var_theta, num_word)
    rescaled_theta = np.array(var_theta)

    ## リスケーリング
    for i in range(len(rescaled_theta)):
        rescaled_theta[i, :] /= rescaling_term
        rescaled_theta[i, :] /= np.sum(rescaled_theta[i, :])
    
    return rescaled_theta.tolist()

def sample_rescaled_theta(alpha_count, var_w, num_word, num_category):
    """
    rescaling-term に基づき theta をサンプリングする.
    共役でない分布なので，一度ディリクレ分布からサンプリングしてから
    重み付けしてリサンプリングする.
    
    Args:
        alpha_count: ディリクレ分布のパラメータ
        var_w: 単語
        num_word: 単語数    
    """
    candidates = [
        [dirichlet(alpha_count[i]) for i in xrange(num_category)]
        for i in xrange(10000)
    ]
    
    ## 重み付け by rescaling_term
    log_weights = [0] * 10000
    for candiate_id, candidate in enumerate(candidates):
        rescaled_term = get_rescaling_term(candidate, num_word)
        for var_w_d in var_w:
            for var_w_d_n in var_w_d:
                log_weights[candiate_id] -= np.log(
                    rescaled_term[var_w_d_n]
                )
    
    ## 重みに基づいてリサンプリング
    log_weights = np.array(log_weights)
    log_weights -= np.max(log_weights)
    weights = np.exp(log_weights)
    weights /= np.sum(weights)
    selected_id = np.random.choice(10000, p=weights)

    return candidates[selected_id]